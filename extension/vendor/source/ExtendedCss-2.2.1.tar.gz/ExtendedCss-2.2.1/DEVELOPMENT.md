# Development Guide

- [Prerequisites](#prerequisites)
- [Getting Started](#getting-started)
    - [Clone the Repository](#clone-the-repository)
    - [Install Dependencies](#install-dependencies)
    - [Environment Configuration](#environment-configuration)
- [Development Workflow](#development-workflow)
    - [Available Commands](#available-commands)
    - [Building](#building)
    - [Linting and Type Checking](#linting-and-type-checking)
    - [Testing](#testing)
        - [Local Tests](#local-tests)
        - [BrowserStack Tests](#browserstack-tests)
        - [Performance Tests](#performance-tests)
    - [Pre-commit Hook](#pre-commit-hook)
    - [Contributing Changes](#contributing-changes)
- [Common Tasks](#common-tasks)
    - [Adding a New Pseudo-class](#adding-a-new-pseudo-class)
    - [Releasing a New Version](#releasing-a-new-version)
    - [Inspecting Build Output](#inspecting-build-output)
- [Troubleshooting](#troubleshooting)
- [Additional Resources](#additional-resources)

## Prerequisites

| Tool    | Version           | Notes                            |
| ------- | ----------------- | -------------------------------- |
| Node.js | >= 22             | Required by development tooling  |
| pnpm    | >=10.33.4 and <11 | Installed via corepack or npm    |

Verify your setup:

```bash
node --version   # must be 22 or higher
pnpm --version   # must be >=10.33.4 and <11
```

No other system-level tools are required for local
development. BrowserStack tests need credentials (see
[Environment Configuration](#environment-configuration)).

## Getting Started

### Clone the Repository

```bash
git clone https://github.com/AdguardTeam/ExtendedCss.git ext-extended-css
cd ext-extended-css
```

AdGuard contributors with access to the private repository can clone it
directly instead:

```bash
git clone git@github.com:AdGuardSoftwareLimited/ext-extended-css.git ext-extended-css
cd ext-extended-css
```

### Install Dependencies

```bash
pnpm install
```

All dependencies are devDependencies — the library ships
with zero runtime dependencies.

### Environment Configuration

The only environment variables are for **BrowserStack
testing**, which is optional for day-to-day development.

1. Copy the example file:

    ```bash
    cp .env-example .env
    ```

2. Fill in your credentials:

    ```text
    BROWSERSTACK_USER=<your-username>
    BROWSERSTACK_KEY=<your-key>
    ```

The `.env` file is gitignored. You do **not** need it for
local builds, linting, or local tests.

## Development Workflow

### Available Commands

| Command                    | Purpose                                     |
| -------------------------- | ------------------------------------------- |
| `pnpm build`               | Build all output formats to `dist/`         |
| `pnpm build:types`         | Emit `.d.ts` declarations only              |
| `pnpm lint`                | Run ESLint + TypeScript type checking       |
| `pnpm test local`          | Run local tests (Vitest + browser mode)     |
| `pnpm test browserstack`   | Run BrowserStack tests (needs creds)        |
| `pnpm test performance`    | Run Vitest performance benchmarks           |
| `pnpm test`                | Run local + BrowserStack tests              |

### Building

```bash
pnpm build
```

This runs `ts-node tools/build`, which uses Rollup to
produce the following bundles in `dist/`:

| File                       | Format        |
| -------------------------- | ------------- |
| `extended-css.esm.js`      | ESM           |
| `extended-css.umd.js`      | UMD           |
| `extended-css.js`          | IIFE          |
| `extended-css.min.js`      | IIFE minified |
| `version.cjs.js`           | CJS (version) |
| `version.esm.mjs`          | ESM (version) |

The `prebuild` script automatically runs `rimraf dist` and
`pnpm build:types` before each build.

To emit only TypeScript declarations:

```bash
pnpm build:types
```

### Linting and Type Checking

```bash
pnpm lint
```

This runs two checks sequentially:

1. `eslint .` — lint all TypeScript files
2. `tsc --project tsconfig.eslint.json --noEmit` — type
   check `src/`, `test/`, and `tools/`

Key ESLint rules enforced:

- 4-space indentation
- 120-character max line length
- JSDoc required on all public APIs (classes, methods,
  functions, class properties) with complete-sentence
  descriptions
- No type annotations in JSDoc tags: types come from
  TypeScript, not JSDoc. Applies to `@param`, `@returns`,
  `@property`, and `@throws` — write
  `@throws An error ...` (not `@throws {Error} An error ...`).
  Type annotations are omitted from all JSDoc tags by
  convention — TypeScript provides them. The jsdoc rules only
  stop *requiring* types (`jsdoc/require-param-type`,
  `jsdoc/require-returns-type`, `jsdoc/require-throws-type`
  are off) and do not forbid them, so this is review-enforced.
- Named imports with at most 2 imports per line

### Testing

#### Local Tests

```bash
pnpm test local
```

This is the primary test command for development. It runs
Vitest projects for jsdom unit tests and Chromium
browser-mode tests. Performance tests and BrowserStack
tests are excluded.

Test files mirror the `src/` structure under `test/`. For
example, `src/selector/parser.ts` is tested by
`test/selector/parser.test.ts`.

Most unit test files run through the jsdom project.
Browser-specific tests run through Vitest browser mode
with Chromium.

#### BrowserStack Tests

```bash
pnpm test browserstack
```

Requires `BROWSERSTACK_USER` and `BROWSERSTACK_KEY` in your
`.env` file. Builds an IIFE bundle plus QUnit test files,
then runs them on BrowserStack.

#### Performance Tests

```bash
pnpm test performance
```

Runs selector performance benchmarks comparing ExtendedCss
v1 and v2. These are not included in the default test suite
and should be run manually when needed.

### Pre-commit Hook

The project uses Husky with a pre-commit hook that runs
`lint-staged`. When you commit, all staged `.ts` files are
automatically linted via ESLint.

No additional setup is needed — `pnpm install` runs
`husky install` via the `prepare` script.

### Contributing Changes

1. Create a branch for your changes.
2. Make your changes, ensuring they follow the code
   guidelines in [AGENTS.md](AGENTS.md).
3. Run the full verification suite:

    ```bash
    pnpm lint
    pnpm build
    pnpm test local
    ```

4. Update or add tests for any changed functionality.
5. Submit a pull request.

## Common Tasks

### Adding a New Pseudo-class

1. Add the pseudo-class name constant in
   `src/common/constants.ts`.
2. Implement the selector tokenizer support in
   `src/selector/tokenizer.ts`.
3. Add parsing logic in `src/selector/parser.ts`.
4. Implement the DOM query matching in
   `src/selector/query.ts` and related utilities under
   `src/selector/utils/`.
5. Add tests in `test/selector/` mirroring the modules
   you changed.
6. Update `README.md` with the new pseudo-class
   documentation.

### Releasing a New Version

This project uses GitHub Actions for releases. The version
is derived from git tags and `CHANGELOG.md` — there is no
`version` field in `package.json`.

1. Make sure all changes for the release are recorded under
   `## [Unreleased]` in `CHANGELOG.md` — the
   `prepare-release` workflow finalizes the version section
   automatically (it moves `[Unreleased]` entries into the
   new version section and rewrites the compare links).
2. Trigger the `prepare-release` workflow with the desired
   tag (e.g. `v2.3.0`).
3. Review and merge the release PR.
4. `publish-release` automatically tags, builds, publishes
   to npm, mirrors to the public repo, and notifies Slack.

### Inspecting Build Output

After running `pnpm build`, the `dist/` directory contains:

- All bundle formats (ESM, UMD, IIFE, minified IIFE)
- Type declarations under `dist/types/`

```bash
pnpm build
ls dist/
```

## Troubleshooting

### `pnpm install` fails with Node.js version error

Development tooling requires Node.js >= 22. Check your
version with `node --version` and upgrade if needed.

### Tests fail with "Cannot find module 'playwright'"

Playwright is a devDependency but may need browser binaries
installed. Run:

```bash
pnpm exec playwright install chromium
```

### `pnpm lint` reports JSDoc errors

Every exported function, class, method, and class property
must have a JSDoc comment with a complete-sentence
description. The ESLint jsdoc plugin enforces `@returns`
tags and `@throws` tags (when applicable). JSDoc tags must
not include type annotations (e.g. write `@throws An error
...`, not `@throws {Error} An error ...`), because types
come from TypeScript. See the JSDoc rules in `.eslintrc.js`.

### BrowserStack tests fail with authentication errors

Ensure your `.env` file contains valid `BROWSERSTACK_USER`
and `BROWSERSTACK_KEY` values. Copy `.env-example` as a
template.

### Build produces stale output

The `prebuild` script runs `rimraf dist` automatically, but
if you see stale files, clean manually:

```bash
rm -rf dist
pnpm build
```

### Type errors in test files

The lint command uses `tsconfig.eslint.json`, which extends
`tsconfig.json` and includes `src/`, `test/`, and `tools/`.
Ensure your test imports match the project's module
resolution settings.

## Additional Resources

- [README.md](README.md) — project overview, API
  documentation, usage examples, and browser compatibility
- [AGENTS.md](AGENTS.md) — code guidelines, architecture
  overview, and project structure
- [CHANGELOG.md](CHANGELOG.md) — version history and
  release notes
- [GitHub Issues](https://github.com/AdguardTeam/ExtendedCss/issues)
  — bug reports and feature requests
